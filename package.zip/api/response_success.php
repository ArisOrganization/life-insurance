<?php 


echo "RECEIVED SUCCESS STATUS....";