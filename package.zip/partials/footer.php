<?php ?>
<footer class="footer" role="contentinfo">  
        <div class="container">
        <div class="row">
            <div class="col-12">
                <div  class="footer-head"> 
                    <div>
                        <p class="copyright-text">Copyrights © 2017 Here4life.co.uk</p>
                    </div>
                </div>
                <div class="footer-main"> 
                    <div>
                        <p>
                            Mason Scott Insurances trading as Here4Life is an Appointed Representative with the Financial Conduct Authority under
                            reference number 754621.
                        </p>
                        <p> Here 4 Life Limited is registered in England and Wales under registration number 11366720.</p>
                        <p>Registered Address: 17 Beecham Court, Smithy Brook Road, Wigan, WN3 6PR.</p>
                    </div>
                </div>
                <div class="business-links">
                    <ul>  
                        <li><a target="_blank" href="/docs/life-privacy.pdf">Privacy Policy</a></li> 
                        <!-- <li><a target="_blank"  href="/docs/cookies.pdf">Cookie Policy</a></li>  -->
                        <li><a target="_blank"  href="/docs/life-terms.pdf">Terms & Conditions</a></li>  
                    </ul>
                </div>
            </div>
        </div>
        </div>
</footer>