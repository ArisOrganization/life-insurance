<?php ?>
<footer class="footer" role="contentinfo">
        <div class="container">
        <div class="row">
            <div class="col-12">
                <div  class="footer-head">
                    <div>
                        <p class="copyright-text">Copyrights © 2017 Here4life.co.uk</p>
                    </div>
                </div>
                <div class="footer-main">
                    <div>
                        <p> Here 4 Life Limited is registered in England and Wales under registration number 11366720.</p>
                        <p> Registered Address: 23 Wigan Road, Ashton-in-Makerfield, Wigan, WN4 9AR.</p>
                    </div>
                </div>
                <div class="business-links">
                    <ul>
                        <li><a target="_blank" href="/docs/life-privacy.pdf">Privacy Policy</a></li>
                        <!-- <li><a target="_blank"  href="/docs/cookies.pdf">Cookie Policy</a></li>  -->
                        <li><a target="_blank"  href="/docs/life-terms.pdf">Terms & Conditions</a></li>
                    </ul>
                </div>
            </div>
        </div>
        </div>
</footer>
