<?php  ?>
<header class="header fixed-header" >
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="header-inner">
                    <div class="header-image">
                        <img src="/assets/logo.png" alt="life insurance logo" />
                    </div>
                      <p class="telephone"><a href="tel:08000886930">0800 088 6930</a></p>
                    <div class="customer-review">
                        <a href="https://www.reviews.co.uk/company-reviews/store/mason-scott" target="__blank">
                            <span>www.reviews.co.uk</span>
                            <img src="/assets/excellent.png" alt="here4life reviews"/>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
